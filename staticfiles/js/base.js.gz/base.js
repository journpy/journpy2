const toggleButton = document.getElementById("toggleButton");


toggleButton.addEventListener("click", function() {
    this.classList.add("active");
});